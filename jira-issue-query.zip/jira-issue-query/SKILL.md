---
name: jira-issue-query
description: 当用户需要查询JIRA工单、搜索JIRA问题或获取JIRAissue列表时使用。适用于在Yonyou JIRA系统（gfjira.yyrd.com）中查询特定项目、类型、状态的任务。支持自定义JQL、分页、批量查询。
---

# JIRA 工单查询技能

这个技能用于封装查询 Yonyou JIRA 系统工单的接口调用，支持灵活的自定义 JQL 查询。

## 文件说明

- `query-jira.ps1` - PowerShell 脚本版本（Windows 推荐）
- `query_jira.py` - Python 脚本版本（跨平台）
- `SKILL.md` - 技能说明文档

---

## 快速开始

### 方式一：PowerShell（推荐 Windows）

```powershell
# 进入脚本目录
cd jira-issue-query

# 执行查询
.\query-jira.ps1 -Jql 'project = UPESN AND issuetype = "支持问题" AND status = "支持确认完成"'
```

### 方式二：Python（跨平台）

```bash
# 安装依赖
pip install requests

# 执行查询
python query_jira.py
```

---

## JQL 常用查询示例

| 场景 | JQL 语句 |
|------|---------|
| 按项目+类型+状态 | `project = UPESN AND issuetype = "支持问题" AND status = "支持确认完成"` |
| 指定工单号 | `issueKey = UPESN-415300` |
| 按领域模块 | `project = UPESN AND "领域模块" in cascadeOption(10707, 10710)` |
| 我的工单 | `assignee = currentUser() AND status != Closed` |
| 最近创建的 | `created >= -7d ORDER BY created DESC` |
| 按优先级 | `project = UPESN AND priority = High` |

---

## 接口信息

| 项目 | 值 |
|------|-----|
| 接口地址 | `https://gfjira.yyrd.com/rest/issueNav/1/issueTable` |
| 请求方法 | POST |
| Content-Type | `application/x-www-form-urlencoded; charset=UTF-8` |

---

## 请求头说明

| Header | 说明 |
|--------|------|
| `Cookie` | **必需**。需要有效的 JSESSIONID 和 atlassian.xsrf.token |
| `origin` | `https://gfjira.yyrd.com` |
| `referer` | 参考页面，如 `https://gfjira.yyrd.com/issues/` |
| `x-atlassian-token` | 固定值 `no-check` |
| `x-requested-with` | 固定值 `XMLHttpRequest` |

---

## 分页参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `startIndex` | 起始索引，从 0 开始 | 0 |
| `pageSize` | 每页数量，最大 100 | 100 |
| `jql` | JQL 查询语句（需 URL 编码） | - |
| `layoutKey` | 固定值 `split-view` | split-view |

---

## 返回字段说明

| 字段 | 说明 |
|------|------|
| `total` | 符合条件的总记录数 |
| `issueKeys` | 工单号列表 |
| `table` | 工单详情数组 |
| `table[].key` | 工单号，如 UPESN-415300 |
| `table[].summary` | 工单标题 |
| `table[].status` | 工单状态 |
| `table[].type.name` | 工单类型名称 |
| `table[].id` | 工单内部 ID |

---

## 常见问题

### 1. Cookie 无效
如果返回 `{"issueTable":null}` 或认证错误，需要重新登录 JIRA 获取有效的 Cookie：
1. 浏览器登录 https://gfjira.yyrd.com
2. 打开开发者工具（F12）→ Network
3. 任意请求中复制 Cookie 头

### 2. JQL 特殊字符
包含空格、括号等特殊字符时，脚本会自动进行 URL 编码。

### 3. CORS 限制
此接口仅限同源调用，不支持直接从前端页面调用。

---

## Python API 使用

```python
from query_jira import JiraQueryTool

# 初始化（使用自定义 Cookie）
tool = JiraQueryTool(cookie="JSESSIONID=xxx; atlassian.xsrf.token=yyy")

# 查询
issues, total = tool.query_issues('project = UPESN AND issuetype = "支持问题"')

# 打印
tool.print_issues('project = UPESN')

# 原始 JSON
result = tool.query('issueKey = UPESN-415300')
```

---

## 在 YonClaw 中的使用

当你说"查询 JIRA 工单"时，我会：
1. 询问你具体的 JQL 条件
2. 使用脚本执行查询
3. 返回格式化结果

例如：
- "帮我查 UPESN 项目最近一周的支持问题"
- "查询工单号 UPESN-415300 的详情"
- "列出所有状态为'待处理'的工单"