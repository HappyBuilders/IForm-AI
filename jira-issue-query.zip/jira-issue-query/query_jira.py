#!/usr/bin/env python3
"""
JIRA 工单查询脚本
支持自定义 JQL 查询、翻页、结果解析

安装依赖: pip install requests urllib3
"""

import urllib.parse
import json
from typing import Optional, List, Dict, Any
from dataclasses import dataclass

# 如需使用，安装: pip install requests
try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

@dataclass
class JiraIssue:
    """工单数据模型"""
    key: str
    summary: str
    status: str
    type_name: str
    issue_id: str
    creator: Optional[str] = None
    assignee: Optional[str] = None
    created: Optional[str] = None
    priority: Optional[str] = None

class JiraQueryTool:
    """JIRA 查询工具类"""

    def __init__(self, cookie: str = None):
        """
        初始化 JIRA 查询工具
        
        Args:
            cookie: Cookie 字符串，格式 "JSESSIONID=xxx; atlassian.xsrf.token=xxx"
        """
        self.base_url = "https://gfjira.yyrd.com"
        self.api_url = f"{self.base_url}/rest/issueNav/1/issueTable"
        
        # 默认 Cookie（需要替换为有效的）
        self.cookie = cookie or "JSESSIONID=510342E26E61185755972043F92BE764; atlassian.xsrf.token=BEM7-G1BN-G1X9-U6BO_b1ad0e9bb053a6df19b7780c3c62afcb77cd31ec_lin"

    def query(self, jql: str, start_index: int = 0, page_size: int = 100) -> Dict[str, Any]:
        """
        查询 JIRA 工单
        
        Args:
            jql: JQL 查询语句
            start_index: 起始索引
            page_size: 每页数量
            
        Returns:
            原始响应字典
        """
        encoded_jql = urllib.parse.quote(jql, safe='')
        body = f"startIndex={start_index}&jql={encoded_jql}&layoutKey=split-view"
        
        headers = {
            "__amdmodulename": "jira/issue/utils/xsrf-token-header",
            "accept": "*/*",
            "accept-language": "zh-CN,zh;q=0.9",
            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "origin": self.base_url,
            "referer": f"{self.base_url}/issues/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "x-atlassian-token": "no-check",
            "x-requested-with": "XMLHttpRequest",
            "Cookie": self.cookie
        }
        
        if HAS_REQUESTS:
            response = requests.post(self.api_url, headers=headers, data=body, timeout=30)
            return response.json()
        else:
            # 使用内置 urllib（仅 Linux/macOS）
            import urllib.request
            data = body.encode('utf-8')
            req = urllib.request.Request(self.api_url, data=data, headers=headers, method='POST')
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode('utf-8'))

    def query_issues(self, jql: str, start_index: int = 0, page_size: int = 100) -> tuple[List[JiraIssue], int]:
        """
        查询并返回工单列表
        
        Args:
            jql: JQL 查询语句
            start_index: 起始索引
            page_size: 每页数量
            
        Returns:
            (工单列表, 总数)
        """
        result = self.query(jql, start_index, page_size)
        table_data = result.get("issueTable", {})
        
        total = table_data.get("total", 0)
        issues = []
        
        for item in table_data.get("table", []):
            issue = JiraIssue(
                key=item.get("key", ""),
                summary=item.get("summary", ""),
                status=item.get("status", ""),
                type_name=item.get("type", {}).get("name", ""),
                issue_id=str(item.get("id", ""))
            )
            issues.append(issue)
        
        return issues, total

    def print_issues(self, jql: str, start_index: int = 0, page_size: int = 100):
        """格式化打印查询结果"""
        issues, total = self.query_issues(jql, start_index, page_size)
        
        print("=" * 70)
        print(f"查询: {jql}")
        print("=" * 70)
        print(f"总记录数: {total}")
        print(f"当前返回: {len(issues)} 条")
        print("=" * 70)
        
        if issues:
            print(f"\n{'工单号':<15} {'状态':<12} {'类型':<10} {'摘要':<30}")
            print("-" * 70)
            for issue in issues:
                summary = issue.summary[:28] + ".." if len(issue.summary) > 30 else issue.summary
                print(f"{issue.key:<15} {issue.status:<12} {issue.type_name:<10} {summary:<30}")
        else:
            print("\n未查到符合条件的工单")

def main():
    """使用示例"""
    tool = JiraQueryTool()
    
    # 示例 JQL
    example_jqls = [
        # 按项目+类型+状态查询
        'project = UPESN AND issuetype = "支持问题" AND status = "支持确认完成"',
        # 按具体工单号查询
        'issueKey = UPESN-415300',
        # 按经办人查询
        'assignee = currentUser() AND status != Closed',
        # 最近7天创建的
        'created >= -7d ORDER BY created DESC',
    ]
    
    # 使用示例
    jql = example_jqls[0]  # 选择要执行的查询
    tool.print_issues(jql)

if __name__ == "__main__":
    import sys
    sys.exit(main())