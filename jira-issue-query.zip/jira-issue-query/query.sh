#!/bin/bash
# JIRA 查询快捷脚本 - macOS/Linux

JIRA_URL="https://gfjira.yyrd.com/rest/issueNav/1/issueTable"

# 默认 Cookie（需要替换为有效的）
COOKIE="JSESSIONID=510342E26E61185755972043F92BE764; atlassian.xsrf.token=BEM7-G1BN-G1X9-U6BO_b1ad0e9bb053a6df19b7780c3c62afcb77cd31ec_lin"

# 函数：执行 JQL 查询
query_jira() {
    local jql="$1"
    local encoded_jql=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$jql', safe=''))")
    local body="startIndex=0&jql=${encoded_jql}&layoutKey=split-view"
    
    curl -s -X POST "$JIRA_URL" \
        -H "origin: https://gfjira.yyrd.com" \
        -H "referer: https://gfjira.yyrd.com/issues/" \
        -H "x-atlassian-token: no-check" \
        -H "x-requested-with: XMLHttpRequest" \
        -H "content-type: application/x-www-form-urlencoded; charset=UTF-8" \
        -H "user-agent: Mozilla/5.0" \
        -H "Cookie: $COOKIE" \
        --data "$body"
}

# 使用示例
echo "=== JIRA 快捷查询 ==="
echo "1. 查询指定工单"
echo "2. 查询项目工单列表"
echo "3. 查询我的工单"
echo ""

# 默认测试
TEST_JQL='project = UPESN AND issuetype = "支持问题" AND status = "支持确认完成"'
echo "测试查询: $TEST_JQL"
echo ""

result=$(query_jira "$TEST_JQL")
echo "$result" | python3 -m json.tool 2>/dev/null || echo "$result"