# JIRA 工单查询脚本
# 支持自定义 JQL 查询和翻页

param(
    [string]$Jql,           # JQL 查询语句，如 "project = UPESN AND issuetype = 支持问题"
    [int]$StartIndex = 0,   # 分页起始位置
    [int]$PageSize = 100    # 每页数量
)

# 配置
$JiraBaseUrl = "https://gfjira.yyrd.com"
$IssueNavApi = "$JiraBaseUrl/rest/issueNav/1/issueTable"

# Cookie 配置（需要替换为有效的）
$Cookie = "JSESSIONID=510342E26E61185755972043F92BE764; atlassian.xsrf.token=BEM7-G1BN-G1X9-U6BO_b1ad0e9bb053a6df19b7780c3c62afcb77cd31ec_lin"

# URL 编码 JQL
$EncodedJql = [System.Web.HttpUtility]::UrlEncode($Jql)

# 构建请求体
$Body = "startIndex=$StartIndex&jql=$EncodedJql&layoutKey=split-view"

# 请求头
$Headers = @{
    "__amdmodulename" = "jira/issue/utils/xsrf-token-header"
    "accept" = "*/*"
    "accept-language" = "zh-CN,zh;q=0.9"
    "content-type" = "application/x-www-form-urlencoded; charset=UTF-8"
    "origin" = $JiraBaseUrl
    "priority" = "u=1, i"
    "referer" = "$JiraBaseUrl/issues/"
    "user-agent" = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    "x-atlassian-token" = "no-check"
    "x-requested-with" = "XMLHttpRequest"
    "Cookie" = $Cookie
}

try {
    Write-Host "查询 JQL: $Jql" -ForegroundColor Cyan
    Write-Host "分页: $StartIndex - $(($StartIndex + $PageSize - 1))" -ForegroundColor Cyan
    Write-Host ""

    $Response = Invoke-RestMethod -Uri $IssueNavApi -Method Post -Headers $Headers -Body $Body -ContentType "application/x-www-form-urlencoded"

    # 解析结果
    $Issues = $Response.issueTable.table | ForEach-Object {
        [PSCustomObject]@{
            Key = $_.key
            Summary = $_.summary
            Status = $_.status
            Type = $_.type.name
            ID = $_.id
        }
    }

    # 输出统计
    Write-Host "=" * 60 -ForegroundColor Green
    Write-Host "查询结果" -ForegroundColor Green
    Write-Host "=" * 60 -ForegroundColor Green
    Write-Host "总记录数: $($Response.issueTable.total)" -ForegroundColor Yellow
    Write-Host "当前页: $($Response.issueTable.page + 1)" -ForegroundColor Yellow
    Write-Host "当前返回: $($Issues.Count) 条" -ForegroundColor Yellow
    Write-Host ""

    # 输出表格
    if ($Issues.Count -gt 0) {
        $Issues | Format-Table -AutoSize
    } else {
        Write-Host "未查到符合条件的工单" -ForegroundColor Red
    }

    # 返回原始 JSON（可选）
    if ($PassThru) {
        $Response.issueTable
    }

} catch {
    Write-Host "查询失败: $_" -ForegroundColor Red
}